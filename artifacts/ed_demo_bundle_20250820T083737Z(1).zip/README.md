# ED Pipeline Demo Bundle

**Notebook:** ed-pipeline-v8-v6merge-phase2-guarded-v1-1_patched_deferred.ipynb

## Run on Kaggle (avoid stuck background job)
1. Go to **Code → Notebooks → New Notebook**.
2. In the top bar, click **File → Import Notebook** and upload this `.ipynb`.
3. **Do NOT** click “Save & Run All”. Instead, use **Run → Run All** to execute interactively.
4. If the UI says “Deferred… set CONFIG[...]”, set `CONFIG['RUN_PIPELINE']=True` and `CONFIG['RUN_UI']=True` in the guards cell and run again.
5. If the UI panel says “Deferred…”, re-run that UI cell once more after the first pass.
6. Logs are written to `/mnt/data/event_log.jsonl`. If that path is not writable on Kaggle, set:
   ```python
   CONFIG["EVENT_LOG_PATH"] = "/kaggle/working/event_log.jsonl"
   ```
   then re-run the calculators/UI cell.

## What’s inside the notebook
- Phase-2 calculators (qSOFA, MEWS, HEART, GRACE (coarse), SOFA (minimal), D-dimer age-adjusted, Troponin Δ, Wells PE/DVT, PERC, PESI/sPESI, SIRS, Sepsis-3, Marburg, GBS, Child-Pugh, corrected calcium, anion gap).
- HL7 paste adapter (Troponin, D-dimer, **+ INR / bilirubin / albumin**) with “Apply HL7 → Labs JSON” button.
- UI widgets for **HEART components**, **PE/PERC**, **Wells-DVT**, **ascites/encephalopathy**.
- ICU availability panel with **next-bed ETA**.

## Notes
- This bundle is self-contained; no sidecars or external services.
- If you see any legacy ICU panel referencing `nonlocal units`, delete that cell; the canonical ICU panel **does not** use `nonlocal`.
